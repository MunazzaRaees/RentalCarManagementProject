#include <iostream>
#include <string>
#include <algorithm>
#include <fstream>
#include <sstream>
#include <thread>
#include <chrono>
#include <conio.h>
using namespace std;

class MainMenu;
class Search;
class BaseClass
{
public:
    virtual void Print() = 0;
};

class CommonDataForManager
{
public:
    int choice;

protected:
    void ReturnToMainMenuOfManager();
};

class CommonDataForCostumer
{
protected:
    int choice;

protected:
    void ReturnToMainMenuOfCustomer();
};

class Search : public CommonDataForManager, public CommonDataForCostumer
{
protected:
    static int serial_no2;
    int choicee, choice6, choice7, choice8, choice9, choice10, choice11, choice12, choice13, choice14, choice15, choice16, choice17, choice18, choice19, choice20;
    int Car[6], numDays;
    string VIPcars[20][20], EconomyCars[2][20], RegularCars[3][20];
    int VIPcarsRent[20][8], EconomyCarsRent[2][20], RegularCarsRent[3][20];
    int VIPcarsSeats[20][20], EconomyCarsSeats[2][20], RegularCarsSeats[3][20];

public:
    void Print();

    void PrintVIPCarDetails(int category)
    {
        int choice, numDays1;

        for (int i = 1; i <= 8; i++)
        {
            if (VIPcars[category][i].empty())
                break;
            cout << "\033[36m";
            cout << "\t" << i << ") " << VIPcars[category][i] << endl;
            cout << "\033[0m";
        }

        cout << endl
            << "Enter Your Choice : ";
        cout << "\033[36m";
        cin >> choice;
        cout << "\033[0m";
        cin.ignore();

        cout << "\033[32m";
        if (choice >= 1 && choice <= 8 && !VIPcars[category][choice].empty())
        {
            cout << endl
                << "\t" << VIPcars[category][choice] << endl;
            cout << "\tPer Day = Rs. " << VIPcarsRent[category][choice] << endl;
            cout << "\tNumber of Seats : " << VIPcarsSeats[category][choice] << endl
                << endl;
            cout << "\033[0m";

        label0:
        ll:
            cout << "Please Enter the Number Of Days You Want to Rent the Car: ";
            cout << "\033[36m";
            cin >> numDays1;
            cout << "\033[0m";
            cin.ignore();
            if (numDays1 < 1)
            {
                cout << "\033[31m";
                cout << "Please Enter a Valid Number" << endl;
                cout << "\033[0m";
                goto ll;
            }
            else if (numDays1 > 90)
            {
                cout << "\033[31m";
                cout << "Sorry, You Cannot Rent a Car For More Than 3 Months (90 days)." << endl;
                cout << "\033[0m";
                goto label0;
            }

            else
            {

                cout << endl
                    << "Thank you! Your Rental Period of " << numDays1 << " Days is Accepted." << endl
                    << endl;
            }
            int userChoice;
        labell:
            cout << "Enter 1 to Cruise In This Luxurious Car on Rent. If not, then press 2 : ";
            cout << "\033[36m";
            cin >> userChoice;
            cout << "\033[0m";
            switch (userChoice)
            {
            case 1:
            {
                cout << "\033[33m";
                cout << endl
                    << "Congratulations on Successfully Renting the \033[32m" << VIPcars[category][choice] << "\033[33m Car." << endl;
                cout << "Get Ready to Embark on an Amazing Journey with this Fantastic Choice." << endl;
                cout << "The Rent Fees are \033[32m" << VIPcarsRent[category][choice] * numDays1 << "PKR\033[33m, and it comes with \033[32m" << VIPcarsSeats[category][choice] << " \033[33mComfortable Seats." << endl;
                cout << "Enjoy the Ride and Make Unforgettable Memories! " << endl
                    << endl;
                cout << "\033[0m";
                ofstream Manager;
                Manager.open("Manager.txt", ios::out | ios::app);
                if (!Manager)
                {
                    cout << "File not created!";
                }
                else
                {
                    serial_no2 = serial_no2 + 1;
                    Manager << serial_no2 << ";" << VIPcars[category][choice] << ";" << VIPcarsRent[category][choice] << ";" << VIPcarsSeats[category][choice] << endl;
                }
            }
            break;
            case 2:
            {
                cout << endl
                    << endl;
                VIPRide();
            }
            break;
            default:
            {
                cout << "\033[31m";
                cout << endl
                    << "Invalid Choice" << endl;
                cout << "\033[0m";
                goto labell;
            }
            }
        }
        else
        {
            cout << "\033[31m";
            cout << endl
                << "Invalid Choice" << endl;
            cout << "\033[0m";
            cout << endl
                << endl;
            VIPRide();
        }
        ReturnToMainMenuOfCustomer();
    }

    void VIPRide()
    {

    g4:
        cout << "\033[33m";
        cout << endl
            << "Unleash Your Desires: Pick the Car that Speaks to Your Soul." << endl
            << endl;
        cout << "\033[36m";
        cout << "\t1) Mercedes Benz " << endl;
        cout << "\t2) Audi A Series" << endl;
        cout << "\t3) RollsRoyce Phantom" << endl;
        cout << "\t4) BMW 5 SERIES" << endl;
        cout << "\t5) BMW 7 SERIES" << endl;
        cout << "\t6) CADILLAC LIMO" << endl
            << endl;
        cout << "\033[0m";
        cout << "Enter Your Choice : ";
        cout << "\033[36m";
        cin >> choice6;
        cout << endl
            << "\033[0m";

        cin.ignore();

        switch (choice6)
        {
        case 1:
        {
            cout << "\033[33m";
            cout << endl
                << "Welcome to the Enchanting World of Mercedes - Benz, where Breathtaking Cars Await your Admiration and Awe!" << endl
                << endl;
            cout << "\033[0m";
            cout << "Car List Sorted According to Low to High Price" << endl
                << endl;

            cout << "\033[32m";
            VIPcars[1][1] = "Mercedes Benz C180 2017";
            VIPcarsRent[1][1] = 20000;
            VIPcarsSeats[1][1] = 5;

            VIPcars[1][2] = "Mercedes Benz E250 2017";
            VIPcarsRent[1][2] = 35000;
            VIPcarsSeats[1][2] = 5;

            VIPcars[1][3] = "Mercedes Benz E200 2019";
            VIPcarsRent[1][3] = 45000;
            VIPcarsSeats[1][3] = 5;

            VIPcars[1][4] = "Mercedes Benz MERCEDES E CLASS 2015";
            VIPcarsRent[1][4] = 90000;
            VIPcarsSeats[1][4] = 5;

            VIPcars[1][5] = "Mercedes Benz MERCEDES S400 2017";
            VIPcarsRent[1][5] = 145000;
            VIPcarsSeats[1][5] = 5;
            cout << "\033[0m";
            PrintVIPCarDetails(1);
            cout << endl;
        }
        break;

        case 2:
        {
            cout << "\033[33m";
            cout << endl
                << "Welcome to the Exhilarating World of Audi A-Series, where Luxury Meets Performance!" << endl
                << endl;
            cout << "\033[0m";
            cout << "Car List Sorted According to Low to High Price" << endl
                << endl;

            cout << "\033[32m";
            VIPcars[2][1] = "Audi A Series A5 2018";
            VIPcarsRent[2][1] = 16000;
            VIPcarsSeats[2][1] = 4;

            VIPcars[2][2] = "Audi A Series A3 2018";
            VIPcarsRent[2][2] = 22000;
            VIPcarsSeats[2][2] = 5;

            VIPcars[2][3] = "Audi A Series A6 2018";
            VIPcarsRent[2][3] = 30000;
            VIPcarsSeats[2][3] = 5;

            VIPcars[2][4] = "Audi A Series A5 2018";
            VIPcarsRent[2][4] = 35000;
            VIPcarsSeats[2][4] = 4;

            VIPcars[2][5] = "Audi A Series A6 2019";
            VIPcarsRent[2][5] = 40000;
            VIPcarsSeats[2][5] = 5;

            VIPcars[2][6] = "Audi A Series A6 2020";
            VIPcarsRent[2][6] = 45000;
            VIPcarsSeats[2][6] = 5;

            VIPcars[2][7] = "Audi A Series AUDI A6 2015";
            VIPcarsRent[2][7] = 75000;
            VIPcarsSeats[2][7] = 5;
            cout << "\033[0m";
            PrintVIPCarDetails(2);
        }
        break;
        case 3:
        {
            cout << "\033[33m";
            cout << "Step Into the Epitome of Luxury with Rolls-Royce Phantom and Let Your Dreams Drive You." << endl
                << endl;
            cout << "\033[0m";
            cout << "Car List Sorted According to Low to High Price" << endl
                << endl;

            cout << "\033[32m";
            VIPcars[3][1] = "RollsRoyce Phantom ROLLS-ROYCE REPLICA BLACK 2017";
            VIPcarsRent[3][1] = 93000;
            VIPcarsSeats[3][1] = 5;

            VIPcars[3][2] = "RollsRoyce Phantom Limo 2015";
            VIPcarsRent[3][2] = 120000;
            VIPcarsSeats[3][2] = 6;

            VIPcars[3][3] = "RollsRoyce Phantom ROLLS ROYCE PHANTOM 2018";
            VIPcarsRent[3][3] = 373000;
            VIPcarsSeats[3][3] = 5;
            cout << "\033[0m";

            PrintVIPCarDetails(3);
        }
        break;

        case 4:
        {
            cout << "\033[33m";
            cout << "Welcome To The BMW Series 5 Car! Prepare to be Amazed by Luxury and Performance!" << endl
                << endl;

            cout << "\033[32m";
            VIPcars[4][1] = "BMW 5 SERIES MERCEDES E CLASS 2015";
            VIPcarsRent[4][1] = 95000;
            VIPcarsSeats[4][1] = 5;
            cout << "\033[0m";

            PrintVIPCarDetails(4);
        }
        break;

        case 5:
        {
            cout << "\033[33m";
            cout << "Welcome To The BMW Series 7 Car! Prepare to be Amazed by Luxury and Performance!" << endl
                << endl;
            cout << "\033[32m";

            VIPcars[5][1] = "BMW 7 SERIES BMW 7 SERIES 2015";
            VIPcarsRent[5][1] = 135000;
            VIPcarsSeats[5][1] = 5;
            cout << "\033[0m";

            PrintVIPCarDetails(5);
        }
        break;

        case 6:
        {
            cout << "\033[33m";
            cout << "Welcome to the CADILLAC LIMO CADDILAC LIMO Car! Experience Luxury and Elegance Like Never Before!" << endl
                << endl;

            cout << "\033[32m";
            VIPcars[6][1] = "CADILLAC LIMO CADDILAC LIMO 2016";
            VIPcarsRent[6][1] = 170000;
            VIPcarsSeats[6][1] = 20;
            cout << "\033[0m";

            PrintVIPCarDetails(6);
        }
        break;

        default:
        {
            cout << "\033[31m";
            cout << endl
                << "Please Enter a Valid Number" << endl;
            cout << "\033[0m";
            goto g4;
        }
        break;
        }
    }

    void PrintEconomyCarDetails(int category)
    {
        int choice, numDays2;

        for (int i = 1; i <= 8; i++)
        {
            if (EconomyCars[category][i].empty())
                break;
            cout << "\033[36m";
            cout << "\t" << i << ") " << EconomyCars[category][i] << endl;
            cout << "\033[0m";
        }

        cout << endl
            << "Enter Your Choice : ";
        cout << "\033[36m";
        cin >> choice;
        cout << "\033[0m";
        cin.ignore();

        cout << "\033[32m";
        if (choice >= 1 && choice <= 8 && !EconomyCars[category][choice].empty())
        {
            cout << endl
                << "\t" << EconomyCars[category][choice] << endl;
            cout << "\tPer Day = Rs. " << EconomyCarsRent[category][choice] << endl;
            cout << "\tNumber of Seats : " << EconomyCarsSeats[category][choice] << endl
                << endl;
            cout << "\033[0m";

        label:
            cout << "Please Enter the Number Of Days You Want to Rent the Car: ";
            cout << "\033[36m";
            cin >> numDays2;
            cout << "\033[0m";
            cin.ignore();
            if (numDays2 < 1)
            {
                cout << "\033[31m";
                cout << "Please Enter a Valid Number" << endl;
                cout << "\033[0m";
            }
            else if (numDays2 > 90)
            {
                cout << "\033[31m";
                cout << "Sorry, You Cannot Rent a Car For More Than 3 Months (90 days)." << endl;
                cout << "\033[0m";
                goto label;
            }

            else
            {
                cout << endl
                    << "Thank you! Your Rental Period of " << numDays2 << " Days is Accepted." << endl
                    << endl;
            }

            int userChoice;
        label1:
            cout << "Enter 1 to Cruise in this Luxurious Car on Rent. If not, then press 2 : ";
            cout << "\033[36m";
            cin >> userChoice;
            cout << "\033[0m";
            switch (userChoice)
            {
            case 1:
            {
                cout << "\033[33m";
                cout << "Congratulations on Successfully Renting the \033[32m" << EconomyCars[category][choice] << " \033[33mCar" << endl;
                cout << "Get Ready to Embark on an Amazing Journey with this Fantastic Choice." << endl;
                cout << "The Rent Fees are \033[32m" << EconomyCarsRent[category][choice] << " PKR\033[33m, and It comes with \033[32m" << EconomyCarsSeats[category][choice] << " \033[33mComfortable Seats." << endl;
                cout << "Enjoy the Ride and Make Unforgettable Memories! " << endl
                    << endl;

                cout << "\033[0m";
                ofstream Manager;
                Manager.open("Manager.txt", ios::out | ios::app);
                if (!Manager)
                {
                    cout << "File not created!";
                }
                else
                {

                    serial_no2 = serial_no2 + 1;
                    Manager << serial_no2 << ";" << EconomyCars[category][choice] << ";" << EconomyCarsRent[category][choice] << ";" << EconomyCarsSeats[category][choice] << endl;
                }
            }
            break;
            case 2:
            {
                cout << endl
                    << endl;
                EconomyClassRide();
            }
            break;
            default:
            {
                cout << "\033[31m";
                cout << endl
                    << "Invalid Choice" << endl;
                cout << "\033[0m";
                goto label1;
            }
            }
        }
        else
        {
            cout << "\033[31m";
            cout << endl
                << "Invalid Choice" << endl;
            cout << "\033[0m";
            cout << endl
                << endl;
            EconomyClassRide();
        }
        ReturnToMainMenuOfCustomer();
    }

    void EconomyClassRide()
    {
    g5:
        cout << "\033[33m";
        cout << endl
            << "Get Ready For a Thrilling Ride! Choose your Dream Economy Ride and Let's Hit the Road! " << endl
            << endl;
        cout << "\033[36m";
        cout << "\t1) Toyota Corolla" << endl;
        cout << "\t2) Toyota Yaris " << endl;
        cout << "\t3) Toyota Aqua " << endl;
        cout << "\t4) HyundaiElantra " << endl
            << endl;
        cout << "\033[0m";
        cout << "Enter your choice : ";
        cout << "\033[36m";
        cin >> choice7;
        cout << "\033[0m";
        switch (choice7)
        {

        case 1:
        {
            cout << "\033[33m";
            cout << endl
                << "Welcome to the Toyota Corolla Car Collection! Prepare to be Amazed by the Elegance, Performance, and Innovation of these Iconic Cars." << endl
                << endl;
            cout << "\033[0m";
            cout << "Car List Sorted According to Low to High Price" << endl
                << endl;

            cout << "\033[32m";
            EconomyCars[1][1] = "Toyota Corolla GLI 2012";
            EconomyCarsRent[1][1] = 3000;
            EconomyCarsSeats[1][1] = 5;

            EconomyCars[1][2] = "Toyota Corolla GLI 2018";
            EconomyCarsRent[1][2] = 3500;
            EconomyCarsSeats[1][2] = 5;

            EconomyCars[1][3] = "Toyota Corolla GLI 2019";
            EconomyCarsRent[1][3] = 3700;
            EconomyCarsSeats[1][3] = 5;

            EconomyCars[1][4] = "Toyota Corolla GLI 2020";
            EconomyCarsRent[1][4] = 4000;
            EconomyCarsSeats[1][4] = 5;

            EconomyCars[1][5] = "Toyota Corolla Altis X 2021";
            EconomyCarsRent[1][5] = 5000;
            EconomyCarsSeats[1][5] = 5;

            EconomyCars[1][6] = "Toyota Corolla GLI 2020";
            EconomyCarsRent[1][6] = 6000;
            EconomyCarsSeats[1][6] = 5;

            EconomyCars[1][7] = "Toyota Corolla Grande 2021";
            EconomyCarsRent[1][7] = 9000;
            EconomyCarsSeats[1][7] = 5;

            cout << "\033[0m";
            PrintEconomyCarDetails(1);
        }
        break;

        case 2:
        {
            cout << "\033[33m";
            cout << endl
                << "Welcome to the Toyota Yaris Car Collection! Get ready to Experience the Perfect Blend of Style, Comfort, and Efficiency." << endl
                << endl;
            cout << "\033[0m";
            cout << "Car List Sorted According to Low to High Price" << endl
                << endl;

            cout << "\033[32m";
            EconomyCars[2][1] = "Toyota Yaris GLI 2020";
            EconomyCarsRent[2][1] = 4000;
            EconomyCarsSeats[2][1] = 5;

            EconomyCars[2][2] = "Toyota Yaris ATIV X 2021";
            EconomyCarsRent[2][2] = 5000;
            EconomyCarsSeats[2][2] = 5;

            cout << "\033[0m";
            PrintEconomyCarDetails(2);
        }
        break;

        case 3:

        {
            cout << "\033[33m";
            cout << endl
                << "Welcome to the Toyota Aqua Car! Vitz car Represents the Epitome of Urban Driving, Designed to Elevate your Daily Commute!" << endl
                << endl;
            cout << "\033[32m";

            EconomyCars[3][1] = "Toyota Aqua Hybrid 2015";
            EconomyCarsRent[3][1] = 4000;
            EconomyCarsSeats[3][1] = 5;
            cout << "\033[0m";

            PrintEconomyCarDetails(3);
        }
        break;

        case 4:
        {
            cout << "\033[33m";
            cout << endl
                << "Welcome to HYUNDAI ELANTRA Car World" << endl
                << endl;
            cout << "\033[32m";
            EconomyCars[4][1] = "Hyundai Elantra HYUNDAI ELANTRA 2015";
            EconomyCarsRent[4][1] = 18000;
            EconomyCarsSeats[4][1] = 5;
            cout << "\033[0m";
            PrintEconomyCarDetails(4);
        }

        break;

        default:
        {
            cout << "\033[31m";
            cout << endl
                << "Please Enter a Valid Number" << endl;
            cout << "\033[0m";
            goto g5;
        }
        }
    }

    void PrintRegularCarDetails(int category)
    {
        int choice, numDays3;

        for (int i = 1; i <= 8; i++)
        {
            if (RegularCars[category][i].empty())
                break;
            cout << "\033[36m";
            cout << "\t" << i << ") " << RegularCars[category][i] << endl;
            cout << "\033[0m";
        }
        cout << endl
            << "Enter Your Choice : ";
        cout << "\033[36m";
        cin >> choice;
        cout << "\033[0m";
        cin.ignore();

        cout << "\033[32m";
        if (choice >= 1 && choice <= 8 && !RegularCars[category][choice].empty())
        {
            cout << endl
                << "\t" << RegularCars[category][choice] << endl;
            cout << "\t"
                << "Per Day = Rs. " << RegularCarsRent[category][choice] << endl;
            cout << "\t"
                << "Number of Seats : " << RegularCarsSeats[category][choice] << endl
                << endl;
            cout << "\033[0m";

        label:
        ll:
            cout << "Please Enter the Number Of Days You Want to Rent the Car: ";
            cout << "\033[36m";
            cin >> numDays3;
            cout << "\033[0m";
            cin.ignore();
            if (numDays3 < 1)
            {
                cout << "\033[31m";
                cout << "Please Enter a Valid Number" << endl;
                cout << "\033[0m";
                goto ll;
            }
            else if (numDays3 > 90)
            {
                cout << "\033[31m";
                cout << "Sorry, You Cannot Rent a Car for More Than 3 Months (90 days)." << endl;
                cout << "\033[0m";
                goto label;
            }

            else
            {
                cout << endl
                    << "Thank you! Your Rental Period of " << numDays3 << " Days is Accepted." << endl
                    << endl;
            }

            int userChoice;
        label1:

            cout << "Enter 1 to Cruise in this Luxurious Car on Rent. If not, then press 2 : ";
            cout << "\033[36m";
            cin >> userChoice;
            cout << "\033[0m";
            switch (userChoice)
            {
            case 1:
            {
                cout << "\033[33m";
                cout << endl
                    << "Congratulations on Successfully Renting the \033[32m" << RegularCars[category][choice] << "\033[33m Car." << endl;
                cout << "Get Ready to Embark on an Amazing Journey with this Fantastic Choice." << endl;
                cout << "The Rent Fees are \033[32m" << RegularCarsRent[category][choice] * numDays3 << "PKR\033[33m, and it comes with \033[32m" << RegularCarsSeats[category][choice] << " \033[33mComfortable Seats." << endl;
                cout << "Enjoy the Ride and Make Unforgettable Memories! " << endl
                    << endl;
                cout << "\033[0m";
                ofstream Manager;
                Manager.open("Manager.txt", ios::out | ios::app);
                if (!Manager)
                {
                    cout << "File not created!";
                }
                else
                {

                    serial_no2 = serial_no2 + 1;
                    Manager << serial_no2 << ";" << RegularCars[category][choice] << ";" << RegularCarsRent[category][choice] << ";" << RegularCarsSeats[category][choice] << endl;
                }
            }
            break;
            case 2:
            {
                cout << endl
                    << endl;
                RegularRide();
            }
            break;
            default:
            {
                cout << "\033[31m";
                cout << endl
                    << "Invalid Choice" << endl;
                cout << "\033[0m";
                goto label1;
            }
            }
        }
        else
        {
            cout << "\033[31m";
            cout << endl
                << "Invalid Choice" << endl;
            cout << "\033[0m";
            cout << endl
                << endl;
            RegularRide();
        }
        ReturnToMainMenuOfCustomer();
    }

    void RegularRide()
    {
    g6:
        cout << "\033[33m";
        cout << endl
            << "Welcome To RegularRide! We Are Absolutely Thrilled To Have You Here With Us!" << endl
            << endl;
        cout << "\033[36m";
        cout << "\t1) Toyota Vitz" << endl;
        cout << "\t2) Honda Civic " << endl;
        cout << "\t3) Honda City " << endl
            << endl;

        cout << "\033[0m";
        cout << "Enter Your Choice : ";
        cout << "\033[36m";
        cin >> choice8;
        cout << "\033[0m";

        switch (choice8)
        {
        case 1:
        {
            cout << "\033[33m";
            cout << endl
                << "Welcome to the Toyota Vitz Car Collection! Each Vitz Car Represents the Epitome of Urban Driving, Designed to Elevate Your Daily Commute!" << endl
                << endl;
            cout << "\033[0m";
            cout << "Car List Sorted According to Low to High Price" << endl
                << endl;
            cout << "\033[32m";

            RegularCars[1][1] = "Toyota Vitz Automatic 2011";
            RegularCarsRent[1][1] = 3000;
            RegularCarsSeats[1][1] = 5;

            RegularCars[1][2] = "Toyota Vitz F 2018";
            RegularCarsRent[1][2] = 3500;
            RegularCarsSeats[1][2] = 4;

            RegularCars[1][3] = "Toyota Vitz F 2019";
            RegularCarsRent[1][3] = 4000;
            RegularCarsSeats[1][3] = 4;

            cout << "\033[0m";
            PrintRegularCarDetails(1);
        }

        break;
        case 2:
        {
            cout << "\033[33m";
            cout << endl
                << "Welcome to the Honda Civic Car Collection! Get Ready to Experience the Perfect Balance of Style and Performance!" << endl
                << endl;
            cout << "\033[0m";
            cout << "Car List Sorted According to Low to High Price" << endl
                << endl;

            cout << "\033[32m";
            RegularCars[2][1] = "Honda Civic test 2018";
            RegularCarsRent[2][1] = 2000;
            RegularCarsSeats[2][1] = 5;

            RegularCars[2][2] = "Honda Civic Reborn 2012";
            RegularCarsRent[2][2] = 3500;
            RegularCarsSeats[2][2] = 5;

            RegularCars[2][3] = "Honda Civic Rebirth 2015";
            RegularCarsRent[2][3] = 5000;
            RegularCarsSeats[2][3] = 5;

            RegularCars[2][4] = "Honda Civic X 2019";
            RegularCarsRent[2][4] = 6500;
            RegularCarsSeats[2][4] = 5;

            RegularCars[2][5] = "Honda Civic X 2020";
            RegularCarsRent[2][5] = 7000;
            RegularCarsSeats[2][5] = 5;

            RegularCars[2][6] = " Honda Civic Oriel 1.8 2021";
            RegularCarsRent[2][6] = 9000;
            RegularCarsSeats[2][6] = 5;

            RegularCars[2][7] = "Honda Civic EL 2021";
            RegularCarsRent[2][7] = 10000;
            RegularCarsSeats[2][7] = 5;

            cout << "\033[0m";
            PrintRegularCarDetails(2);
        }
        break;

        case 3:
        {
            cout << "\033[33m";
            cout << endl
                << "Welcome to the Honda City Car Collection! Get Ready to Experience the Perfect Balance of Style and Performance!" << endl
                << endl;
            cout << "\033[0m";
            cout << "Car List Sorted According to Low to High Price" << endl
                << endl;

            cout << "\033[32m";
            RegularCars[3][1] = "Honda City Aspire 2018";
            RegularCarsRent[3][1] = 3000;
            RegularCarsSeats[3][1] = 5;

            RegularCars[3][2] = "Honda City 1.3 2021";
            RegularCarsRent[3][2] = 3500;
            RegularCarsSeats[3][2] = 5;

            RegularCars[3][3] = "Honda City Aspire 2014";
            RegularCarsRent[3][3] = 4000;
            RegularCarsSeats[3][3] = 5;

            RegularCars[3][4] = "Honda City 1.3 2020";
            RegularCarsRent[3][4] = 4500;
            RegularCarsSeats[3][4] = 5;

            RegularCars[3][5] = "Honda City 1.3 2017";
            RegularCarsRent[3][5] = 6000;
            RegularCarsSeats[3][5] = 5;

            cout << "\033[0m";
            PrintRegularCarDetails(3);
        }

        default:
        {
            cout << "\033[31m";
            cout << endl
                << "Please Enter a Valid Number" << endl;
            cout << "\033[0m";
            goto g6;
        }
        }
    }

    void PrintNewlyAddedCarsDetails(const string& carName, const string& carRent, const string& carSeats)
    {
        int choice, numDays, serial;
        string serialNo;

        ifstream inFile("NewlyAddedCars.txt");
        if (!inFile)
        {
            cout << "File not found: NewlyAddedCars.txt" << endl;
            return;
        }

        string line;
        while (getline(inFile, line))
        {
            stringstream ss(line);

            getline(ss, serialNo, ';');
        }

        serial = stoi(serialNo);

        inFile.close();

    g:
        cout << endl
            << "Enter Your Choice : ";
        cout << "\033[36m";
        cin >> choice;
        cout << "\033[0m";
        cin.ignore();

        if (choice > serial)
        {
            cout << "\033[31m";
            cout << "Please Enter a Valid Number" << endl;
            cout << "\033[0m";
            goto g;
        }

    label0:
    ll:
        cout << endl
            << "Please Enter the Number Of Days You Want to Rent the Car: ";
        cout << "\033[36m";
        cin >> numDays;
        cout << "\033[0m";
        cin.ignore();
        if (numDays < 1)
        {
            cout << "\033[31m";
            cout << "Please Enter a Valid Number" << endl;
            cout << "\033[0m";
            goto ll;
        }
        else if (numDays > 90)
        {
            cout << "\033[31m";
            cout << "Sorry, You Cannot Rent a Car for More Than 3 Months (90 days)." << endl;
            cout << "\033[0m";
            goto label0;
        }

        else
        {

            cout << endl
                << "Thank you! Your Rental Period of " << numDays << " Days is Accepted." << endl
                << endl;
        }

        int userChoice;
    labell:
        cout << "Enter 1 to Cruise in this Luxurious Car on Rent. If not, then press 2 : ";
        cout << "\033[36m";
        cin >> userChoice;
        cout << "\033[0m";
        switch (userChoice)
        {
        case 1:
        {
            cout << "\033[33m";
            int rent = stoi(carRent);
            cout << endl
                << "Congratulations on Successfully Renting the \033[32m" << carName << "\033[33m Car." << endl;
            cout << "Get Ready to Embark on an Amazing Journey with this Fantastic Choice." << endl;
            cout << "The Rent Fees are \033[32m" << rent * numDays << "PKR\033[33m, and it comes with \033[32m" << carSeats << " \033[33mComfortable Seats." << endl;
            cout << "Enjoy the Ride and Make Unforgettable Memories! " << endl
                << endl;
            cout << "\033[0m";

            ofstream Manager;
            Manager.open("Manager.txt", ios::out | ios::app);
            if (!Manager)
            {
                cout << "File not created!";
            }
            else
            {
                serial_no2 = serial_no2 + 1;
                Manager << serial_no2 << ";" << carName << ";" << carRent << ";" << carSeats << endl;
            }
        }
        break;
        case 2:
        {
            cout << endl
                << endl;
            NewlyAddedCars();
        }
        break;
        default:
        {
            cout << "\033[31m";
            cout << endl
                << "Invalid Choice" << endl;
            cout << "\033[0m";
            goto labell;
        }
        }
        ReturnToMainMenuOfCustomer();
    }

    void NewlyAddedCars()
    {
        string serialNo, carName, carRent, carSeats;
        ifstream inFile("NewlyAddedCars.txt");
        if (!inFile)
        {
            cout << "File not found: NewlyAddedCars.txt" << endl;
            return;
        }

        cout << "\033[33m";
        cout << endl
            << endl
            << "NEWLY ADDED CARS" << endl
            << endl;
        cout << "\033[0m";

        string line;
        while (getline(inFile, line))
        {
            stringstream ss(line);

            getline(ss, serialNo, ';');
            getline(ss, carName, ';');
            getline(ss, carRent, ';');
            getline(ss, carSeats, ';');

            cout << "\t" << serialNo << ") ";
            cout << "Car Name: "
                << "\033[35m" << carName << "\033[0m" << endl;
            cout << "\tCar Rent: "
                << "\033[35m" << carRent << "\033[0m" << endl;
            cout << "\tCar Seats: "
                << "\033[35m" << carSeats << "\033[0m" << endl;
            cout << endl;
        }

        inFile.close();
        PrintNewlyAddedCarsDetails(carName, carRent, carSeats);
    }
};
int Search::serial_no2 = 0;

class Manager : public Search
{
    static int serial_no3;

public:
    void Print();

    void AddData()
    {
        string carName;
        int carRent;
        int carSeats;

        int userChoice;
    goo:
        cout << "\033[34m";
        cout << endl
            << "Do You Want to Add a New Car?  Press '1' for Yes and '2' for No " << endl;
        cout << "\033[0m";
        cout << endl
            << "Enter Your Choice : ";
        cout << "\033[36m";
        cin >> userChoice;
        cout << "\033[0m";

        switch (userChoice)
        {
        case 1:
        {
            cout << endl
                << "Enter Car Name: ";
            cin.ignore();
            cout << "\033[36m";
            getline(cin, carName);
            cout << "\033[0m";

            cout << "Enter Car Rent : ";
            cout << "\033[36m";
            cin >> carRent;
            cout << "\033[0m";

            cout << "Enter Number of Seats : ";
            cout << "\033[36m";
            cin >> carSeats;
            cout << "\033[0m";

            ofstream R;
            R.open("NewlyAddedCars.txt", ios::out | ios::app);
            if (!R)
            {
                cout << "File not created!";
            }
            else
            {
                serial_no3 = serial_no3 + 1;
                R << serial_no3 << ";" << carName << ";" << carRent << ";" << carSeats << endl;
            }
        }
        break;

        case 2:
        {
            Manager m;
            m.ReturnToMainMenuOfManager();
        }
        default:
            cout << "\033[31m";
            cout << "Invalid Input" << endl;
            cout << "\033[0m";
            goto goo;
        }
        cout << "\033[33m";
        cout << endl
            << "Car Added Successfully!" << endl
            << endl;
        Manager m;
        m.ReturnToMainMenuOfManager();
    }

    void DeleteCar()
    {
        int categoryChoice;
        cout << endl
            << "\033[35mWhich category of cars would you like to delete from?\033[0m" << endl;
        cout << endl
            << "\033[36m \t1) VIP" << endl;
        cout << "\t2) Economy" << endl;
        cout << "\t3) Regular" << endl;
        cout << "\t4) Newly Added" << endl
            << endl;
        cout << "\033[0m";
        cout << "Enter : ";
        cout << "\033[36m";
        cin >> categoryChoice;
        cout << "\033[30m";
        switch (categoryChoice)
        {
        case 1:
            DeleteCarOfType("VIP");
            break;
        case 2:
            DeleteCarOfType("Economy");
            break;
        case 3:
            DeleteCarOfType("Regular");
            break;
        case 4:
            DeleteNewlyAddedCar();
            break;
        default:
            cout << "\033[31m";
            cout << "Invalid choice." << endl;
            cout << "\033[0m";
            Manager m;
            m.ReturnToMainMenuOfManager();
        }
    }

    void DeleteCarOfType(const string& carType)
    {
        string fileName;

        if (carType == "VIP")
        {
            fileName = "VIPcars.txt";
        }
        else if (carType == "Economy")
        {
            fileName = "EconomyCars.txt";
        }
        else if (carType == "Regular")
        {
            fileName = "RegularCars.txt";
        }
        else
        {
            cout << "\033[31m";
            cout << "Invalid car type." << endl;
            cout << "\033[0m";
            Manager m;
            m.ReturnToMainMenuOfManager();
        }

        ifstream inFile(fileName);
        if (!inFile)
        {
            cout << "File not found: " << fileName << endl;
            return;
        }

        int serialNoToDelete;
        cout << endl
            << "\033[34mEnter the serial number of the " << carType << " car you want to delete: \033[0m";
        cin >> serialNoToDelete;

        // Create a temporary file to hold updated data
        ofstream tempFile("temp.txt", ios::out);
        if (!tempFile)
        {
            cout << "File not created!" << endl;
            inFile.close();
            return;
        }

        string line;
        bool carDeleted = false;

        while (getline(inFile, line))
        {
            stringstream ss(line);
            string serialNo, carName, carRent, carSeats;

            getline(ss, serialNo, ';');
            getline(ss, carName, ';');
            getline(ss, carRent, ';');
            getline(ss, carSeats, ';');

            // Convert the serial number to an integer
            int currentSerialNo = stoi(serialNo);

            // Compare the current serial number with the one to delete
            if (currentSerialNo == serialNoToDelete)
            {
                carDeleted = true;
                continue; // Skip writing this line to the temp file
            }

            // Write the line to the temporary file
            tempFile << line << endl;
        }

        inFile.close();
        tempFile.close();

        if (carDeleted)
        {
            // Remove the original file and rename the temporary file
            remove(fileName.c_str());
            rename("temp.txt", fileName.c_str());

            cout << endl
                << "\033[33m" << carType << " Car Deleted Successfully!\033[0m" << endl;
            Manager m;
            m.ReturnToMainMenuOfManager();
        }
        else
        {
            cout << "\033[31m";
            cout << "Car not found with the provided serial number." << endl;
            cout << "\033[0m";
            Manager m;
            m.ReturnToMainMenuOfManager();
        }
    }

    void DeleteNewlyAddedCar()
    {
        ifstream inFile("NewlyAddedCars.txt");
        if (!inFile)
        {
            cout << "File not found: NewlyAddedCars.txt" << endl;
            return;
        }

        cout << "\033[34mEnter the serial number of the newly added car you want to delete: \033[34m";
        string serialNoToDelete;
        cin.ignore(); // Clear any previous newline from the input buffer
        cout << "\033[36m";
        getline(cin, serialNoToDelete);
        cout << "\033[0m";

        bool found = false;
        string carInfoToDelete;

        string line;
        while (getline(inFile, line))
        {
            stringstream ss(line);
            string serialNo, carName, carRent, carSeats;

            getline(ss, serialNo, ';');
            getline(ss, carName, ';');
            getline(ss, carRent, ';');
            getline(ss, carSeats, ';');

            // Compare the current serial number with the one to delete
            if (serialNo == serialNoToDelete)
            {
                found = true;
                carInfoToDelete = line;
                break;
            }
        }

        inFile.close();

        if (found)
        {
            // Create a temporary file with a unique name
            string tempFileName = "temp_" + to_string(time(0)) + ".txt";
            ofstream tempFile(tempFileName, ios::out);
            if (!tempFile)
            {
                cout << "File not created!" << endl;
                return;
            }

            inFile.open("NewlyAddedCars.txt");
            while (getline(inFile, line))
            {
                if (line != carInfoToDelete)
                {
                    // Write the line to the temporary file
                    tempFile << line << endl;
                }
            }

            inFile.close();
            tempFile.close();

            // Remove the original file and rename the temporary file
            remove("NewlyAddedCars.txt");
            rename(tempFileName.c_str(), "NewlyAddedCars.txt");

            cout << endl
                << "\033[33mNewly Added Car Deleted Successfully!\033[0m" << endl;
            Manager m;
            m.ReturnToMainMenuOfManager();
        }
        else
        {
            cout << "\033[31m";
            cout << "Car Not Found with the Provided Serial Number." << endl;
            cout << "\033[0m";
            Manager m;
            m.ReturnToMainMenuOfManager();
        }
    }

    void Display()
    {
        int categoryChoice;
        cout << endl
            << "\033[35mWhich category of cars would you like to display?\033[0m" << endl;
        cout << endl
            << "\033[36m \t1) VIP" << endl;
        cout << "\t2) Economy" << endl;
        cout << "\t3) Regular" << endl;
        cout << "\t4) Newly Added" << endl
            << endl;
        cout << "\033[0m";
        cout << "Enter : ";
        cout << "\033[36m";
        cin >> categoryChoice;
        cout << "\033[0m";

        switch (categoryChoice)
        {
        case 1:
            cout << "\033[35m";
            cout << endl;
            DisplayCarsFromFile("VIPcars.txt");
            cout << "\033[0m";

            break;
        case 2:
            cout << "\033[35m";
            cout << endl;
            DisplayCarsFromFile("EconomyCars.txt");
            cout << "\033[0m";
            break;
        case 3:
            cout << "\033[35m";
            cout << endl;
            DisplayCarsFromFile("RegularCars.txt");
            cout << "\033[0m";
            break;
        case 4:
            DisplayCarsFromFile("NewlyAddedCars.txt");
            cout << "\033[0m";
            break;
        default:
            cout << "\033[31m";
            cout << "Invalid choice." << endl;
            cout << "\033[0m";
            Manager m;
            m.ReturnToMainMenuOfManager();
        }
    }

    void DisplayCarsFromFile(const string& fileName)
    {
        ifstream inFile(fileName);
        if (!inFile)
        {
            cout << "File not found: " << fileName << endl;
            return;
        }

        string line;
        int serialNo = 0;

        while (getline(inFile, line))
        {
            stringstream ss(line);
            string serialNoStr, carName, carRent, carSeats;

            serialNo++; // Increment serial number

            getline(ss, serialNoStr, ';'); // Read and discard serial number
            getline(ss, carName, ';');
            getline(ss, carRent, ';');
            getline(ss, carSeats, ';');

            cout << "Serial No: " << serialNo << endl;
            cout << "Car Name: " << carName << endl;
            cout << "Car Rent: " << carRent << endl;
            cout << "Car Seats: " << carSeats << endl
                << endl;
        }
        ReturnToMainMenuOfManager();

        inFile.close();
    }
};
int Manager::serial_no3 = 0;

class Customer : public CommonDataForCostumer
{
    bool hasAddedData = false;
    int choice4, choice5, numDays, age;
    static int serial_no;
    string name;
    string license;
    string phoneNumber;

public:
    void AddYourData()
    {
        cin.ignore();
        cout << endl
            << "Please Enter Your Name: ";
        cout << "\033[36m";
        getline(cin, name);
        cout << "\033[0m";

        cout << "Please Enter Your Age: ";
        cout << "\033[36m";
        cin >> age;
        cout << "\033[0m";
        if (age < 18)
        {
            cout << "\033[31m";
            cout << endl
                << "Really Sorry, You must be at least 18 years old to rent a car." << endl;
            cout << "\033[0m";
            ReturnToMainMenuOfCustomer();
        }

        string phoneNumberInput;
        bool validPhoneNumber = false;

        while (!validPhoneNumber)
        {
            cout << "Please Enter Your Phone Number (11 digits): ";
            cin.ignore(); // Clear the newline character
            cout << "\033[36m";
            getline(cin, phoneNumberInput);
            cout << "\033[0m";

            if (phoneNumberInput.length() == 11 && all_of(phoneNumberInput.begin(), phoneNumberInput.end(), isdigit))
            {
                validPhoneNumber = true;
            }
            else if (phoneNumberInput.length() > 11)
            {
                cout << "\033[31m";
                cout << endl
                    << "Phone Number should not exceed 11 digits" << endl
                    << endl;
                cout << "\033[0m";
            }
            else
            {
                cout << "\033[31m";
                cout << endl
                    << "Please Enter a Valid Phone Number of 11 Digits" << endl
                    << endl;
                cout << "\033[0m";
            }
        }

        phoneNumber = phoneNumberInput;

    label2:
        cout << "Do you have a valid driver's license? (yes/no) : ";
        cout << "\033[36m";
        getline(cin, license);
        cout << "\033[0m";

        transform(license.begin(), license.end(), license.begin(), ::tolower);

        if (license == "yes")
        {
            cout << "\033[33m";
            cout << endl
                << "Great! You Have Your License. You Can Proceed With Renting a Car." << endl
                << endl;
            cout << "\033[0m";
        }
        else if (license == "no")
        {
            cout << "\033[31m";
            cout << endl
                << "Sorry, You Need to Have a Valid Driver's License to Rent a Car." << endl
                << endl;
            cout << "\033[0m";
            ReturnToMainMenuOfCustomer();
        }
        else
        {
            cout << "\033[31m";
            cout << "Please Enter a Valid Answer" << endl;
            cout << "\033[0m";
            goto label2;
        }

    go1:
    go2:
        cout << "Enter Number of Days you want a car on Rent : ";
        cout << "\033[36m";
        cin >> numDays;
        cout << "\033[0m";
        if (numDays < 0)
        {
            cout << "\033[31m";
            cout << "Please Enter a Positive Number" << endl;
            cout << "\033[0m";
            goto go1;
        }
        else if (numDays > 90)
        {
            cout << "\033[31m";
            cout << endl
                << "You can't take a car on rent for more than 3 months" << endl
                << endl;
            cout << "\033[0m";
            goto go2;
        }

        cout << "\033[33m";
        cout << endl
            << "Congratulations! Your Verification is Complete , You Can Now Select your Car from our Exciting Car Collection,Thankyou!" << endl
            << endl;
        cout << "\033[0m";
        StoreCustomerDataInFile();

        ifstream inFile("my_file.txt");
        if (!inFile)
        {
            cout << "File not found: my_file.txt" << endl;
            return;
        }

        string line;
        bool found = false;

        while (getline(inFile, line))
        {
            stringstream ss(line);
            string serialNo, custName, custAge, custPhoneNumber, custLicense, custNumDays;

            getline(ss, serialNo, ';');
            getline(ss, custName, ';');
            getline(ss, custAge, ';');
            getline(ss, custPhoneNumber, ';');
            getline(ss, custLicense, ';');
            getline(ss, custNumDays, ';');

            int currentSerialNo = stoi(serialNo);

            cout << endl
                << "Your Serial Number: \033[36m" << serialNo << "\033[0m" << endl;
            cout << "Your Name: \033[36m" << custName << "\033[0m" << endl;
            cout << "Your Age: \033[36m" << custAge << "\033[0m" << endl;
            cout << "Your Phone Number: \033[36m" << custPhoneNumber << "\033[0m" << endl;
            cout << "Your License: \033[36m" << custLicense << "\033[0m" << endl;
            cout << "Your Rental Days: \033[36m" << custNumDays << "\033[0m" << endl;
            break;
        }

        inFile.close();
    }

    void UpdateYourData()
    {
        int targetSerial;
        cout << "\033[32m";
        cout << endl
            << "Note : You Can Only Update Number of Days , Otherwise Go Back and Registered Yourself Again , Thankyou" << endl
            << endl;
        cout << "\033[0m";
        cout << "Enter the Serial Number of the Customer You Want to Update: ";
        cout << "\033[36m";
        cin >> targetSerial;
        cout << "\033[0m";

        ifstream read;
        read.open("my_file.txt", ios::in);
        if (read.fail())
        {
            cout << "Error Opening file" << endl;
            return;
        }

        ofstream tempFile("temp.txt", ios::out);
        if (!tempFile)
        {
            cout << "Error Creating Temporary File" << endl;
            return;
        }

        bool updated = false;
        string line;

        while (getline(read, line))
        {
            stringstream ss(line);
            string custSerialNo, custName, custAge, custPhoneNumber, custLicense, custNumDays;
            getline(ss, custSerialNo, ';');
            getline(ss, custName, ';');
            getline(ss, custAge, ';');
            getline(ss, custPhoneNumber, ';');
            getline(ss, custLicense, ';');
            getline(ss, custNumDays, ';');

            int currentSerialNo = stoi(custSerialNo);
            if (currentSerialNo == targetSerial)
            {
                updated = true;
                cout << endl
                    << "Enter the New Number of Days : ";
                int newNumDays;
                cout << "\033[36m";
                cin >> newNumDays;
                cout << "\033[0m";
                custNumDays = to_string(newNumDays);

                // Update the line with the new numDays
                string updatedLine = custSerialNo + ";" + custName + ";" + custAge + ";" + custPhoneNumber + ";" + custLicense + ";" + custNumDays;
                tempFile << updatedLine << endl;
            }
            else
            {
                tempFile << line << endl;
            }
        }

        read.close();
        tempFile.close();

        if (updated)
        {
            remove("my_file.txt");
            rename("temp.txt", "my_file.txt");
            cout << "\033[33m";
            cout << endl
                << "Data updated successfully!" << endl;
            cout << "\033[0m";
        }
        else
        {
            cout << "\033[31m";
            cout << endl
                << "Customer Not Found With The Provided Serial Number." << endl
                << endl;
            cout << "\033[0m";
        }

        ReturnToMainMenuOfCustomer();
    }

    void DisplayCustomerData()
    {
        int targetSerial;
        cout << "\033[0m";
        cout << endl
            << "Enter the Serial Number of the Customer You Want to Display: ";
        cout << "\033[36m";
        cin >> targetSerial;
        cout << "\033[0m";

        ifstream inFile("my_file.txt");
        if (!inFile)
        {
            cout << "File not found: my_file.txt" << endl;
            return;
        }

        string line;
        bool found = false;

        while (getline(inFile, line))
        {
            stringstream ss(line);
            string serialNo, custName, custAge, custPhoneNumber, custLicense, custNumDays;

            getline(ss, serialNo, ';');
            getline(ss, custName, ';');
            getline(ss, custAge, ';');
            getline(ss, custPhoneNumber, ';');
            getline(ss, custLicense, ';');
            getline(ss, custNumDays, ';');

            int currentSerialNo = stoi(serialNo);

            if (currentSerialNo == targetSerial)
            {
                found = true;
                cout << endl
                    << "Your Serial Number: \033[36m" << serialNo << "\033[0m" << endl;
                cout << "Your Name: \033[36m" << custName << "\033[0m" << endl;
                cout << "Your Age: \033[36m" << custAge << "\033[0m" << endl;
                cout << "Your Phone Number: \033[36m" << custPhoneNumber << "\033[0m" << endl;
                cout << "Your License: \033[36m" << custLicense << "\033[0m" << endl;
                cout << "Your Rental Days: \033[36m" << custNumDays << "\033[0m" << endl;
                break;
            }
        }

        inFile.close();

        if (!found)
        {
            cout << "\033[31m";
            cout << endl
                << "Customer Not Found With The Provided Serial Number." << endl;
            cout << "\033[0m";
        }
        Customer c;
        c.ReturnToMainMenuOfCustomer();
    }

    void StoreCustomerDataInFile()
    {
        ofstream my_file;
        my_file.open("my_file.txt", ios::out | ios::app);
        if (!my_file)
        {
            cout << "File not created!";
        }
        else
        {
            serial_no = serial_no + 1;
            my_file << serial_no << ";" << name << ";" << age << ";" << phoneNumber << ";" << license << ";" << numDays << endl;

            // my_file.close();
        }
    }

    void CustomerData();
};
int Customer::serial_no = 0;

class Report : public CommonDataForManager
{
public:
    void Print();

    void RentedCarsReport()
    {

        cout << endl
            << "\033[33mRENTED CARS REPORT\033[0m" << endl;

        ifstream managerFile("Manager.txt");
        if (!managerFile)
        {
            cout << "File not found: Manager.txt" << endl;
            return;
        }

        string line;
        while (getline(managerFile, line))
        {
            stringstream ss(line);
            string serialNo, carName, carRent, carSeats;

            getline(ss, serialNo, ';');
            getline(ss, carName, ';');
            getline(ss, carRent, ';');
            getline(ss, carSeats, ';');

            cout << endl
                << "\033[0mSerial Number : "
                << "\033[36m" << serialNo << endl
                << "\033[0mCar Name : ";
            cout << "\033[36m" << carName << endl
                << "\033[0mCar Rent Per Day : "
                << "\033[36m" << carRent << endl;
            cout << "\033[0mNumber of Seats : "
                << "\033[36m" << carSeats << endl
                << endl;
        }

        managerFile.close();

        ReturnToMainMenuOfManager();
    }
};

class MainMenu
{
    int choice, user_or_manager;

    int managerAccessAttempts = 0;
    const string correctManagerPassword = "Error404";

public:
    void PrintCostomerMenu()
    {
        cout << endl
            << endl
            << "\033[36m\t\t\t\t\t        MAIN MENU FOR CUSTOMER \033[0m" << endl;
        cout << endl
            << "\t\t\t\t\t\033[32mChoose any of the following Option " << endl
            << endl
            << endl;
        cout << "\t\033[34m1) Manage Your Data " << endl;
        cout << "\t2) Exit\033[0m" << endl
            << endl;
    label:
        cout << "Enter : ";
        cout << "\033[36m";
        cin >> choice;
        cout << "\033[0m";
        switch (choice)
        {
        case 1:
        {
            Customer Obj;
            Obj.CustomerData();
        }
        break;
        case 2:
        {
            PrintFirstChoice();
        }
        break;
        default:
        {
            cout << endl
                << "\033[31mInvalid Input , Please Enter your choice again\033[0m" << endl
                << endl;
            goto label;
        }
        }
    }

    void PrintManagerMenu()
    {
        cout << endl
            << endl
            << "\033[36m\t\t\t\t\t        MAIN MENU FOR MANAGER \033[0m" << endl;
        cout << endl
            << "\t\t\t\t\t\033[32mChoose any of the following Option \033[0m" << endl
            << endl
            << endl;
        cout << "\t\033[35m1) Manage Data " << endl;
        cout << "\t2) Reports  " << endl;
        cout << "\t3) Exit\033[0m" << endl
            << endl;
    label:
        cout << "Enter : ";
        cout << "\033[36m";
        cin >> choice;
        cout << "\033[0m";
        switch (choice)
        {
        case 1:
        {
            Manager manageDataObj;
            manageDataObj.Print();
        }
        break;
        case 2:
        {
            Report reportObj;
            reportObj.Print();
        }
        break;
        case 3:
        {
            PrintFirstChoice();
        }
        break;
        default:
        {
            cout << endl
                << "\033[31mInvalid Input , Please Enter your choice again\033[0m" << endl
                << endl;
            goto label;
        }
        }
    }

    void PrintFirstChoice()
    {
        cout << endl
            << endl;
        cout << "\t\t\033[33m    Welcome to our Car Rental Service - The perfect solution for your travel needs!\033[0m" << endl
            << endl;
        cout << "\t\033[32m \t\t      1) MANAGER \t\t Or \t\t     2) CUSTOMER\033[0m" << endl
            << endl;

        cout << "Enter 1 if you are a Manager or Enter 2 if you are a Customer: ";
        cout << "\033[36m";
        cin >> user_or_manager;
        cin.ignore();
        cout << "\033[0m";

        switch (user_or_manager)
        {
        case 1:
        {
            PrintManagerMenuWithPassword();
        }
        break;
        case 2:
        {
            PrintCostomerMenu();
        }
        break;
        default:
        {
            cout << endl
                << "\033[31mInvalid Input , Please Enter your choice again\033[0m" << endl
                << endl;
            cin.ignore();

            PrintFirstChoice();
        }
        }
    }

    void PrintManagerMenuWithPassword()
    {
        cout << endl;
        cout << "\033[33mManager's Password : \033[31m Error404\033[0m";

        // Sleep for 3 seconds
        this_thread::sleep_for(chrono::seconds(3));

        // Clear the password
        cout << "\r" << string(30, ' ');

        cout << endl
            << "Enter Manager Password: ";
        string inputPassword;
        cout << "\033[36m";
        cin >> inputPassword;
        cout << "\033[0m";

        if (inputPassword == correctManagerPassword)
        {
            managerAccessAttempts = 0;
            PrintManagerMenu();
        }
        else
        {
            cout << "\033[31m";
            cout << endl
                << "Access Denied!" << endl;
            cout << "\033[0m";

            managerAccessAttempts++;

            if (managerAccessAttempts >= 3)
            {
                cout << "\033[31m";
                cout << endl
                    << "Too Many Failed Attempts. Try Again Later." << endl;
                cout << "\033[0m";
                this_thread::sleep_for(chrono::seconds(8));
                PrintFirstChoice();
            }
            else
            {
                PrintFirstChoice();
            }
        }
    }
};

void CommonDataForManager::ReturnToMainMenuOfManager()
{
    MainMenu m;
    m.PrintManagerMenu();
}

void CommonDataForCostumer::ReturnToMainMenuOfCustomer()
{
    MainMenu m;
    m.PrintCostomerMenu();
}

void Manager::Print()
{
    int choice;
    {
        cout << endl
            << "\t\t\t\t\t\033[32mChoose any of the following Option \033[0m" << endl
            << endl;
        cout << "\033[35m\t1) Add Data " << endl;
        cout << "\t2) Delete" << endl;
        cout << "\t3) Display" << endl;
        cout << "\t4) Exit\033[0m" << endl
            << endl;

    label:
        cout << "Enter : ";
        cout << "\033[36m";
        cin >> choice;
        cout << "\033[0m";
        switch (choice)
        {
        case 1:
        {
            AddData();
        }
        break;
        case 2:
        {
            DeleteCar();
        }
        break;
        case 3:
        {
            Display();
        }
        break;
        case 4:
        {
            ReturnToMainMenuOfManager();
        }
        break;
        default:
        {
            cout << endl
                << "\033[31mInvalid Input , Please Enter your choice again\033[0m" << endl
                << endl;
            goto label;
        }
        }
    }
}

void Customer::CustomerData()
{
    if (!hasAddedData)
    {

        AddYourData();

        hasAddedData = true;
        cout << "Information added successfully!" << endl;
    }

    while (true)
    {
        cout << endl
            << "\t\t\t\t\t\033[32mChoose any of the following Option \033[0m" << endl
            << endl;
        //     cout << "\033[34m\t1) Add Data " << endl;
        cout << "\t1) Update Data" << endl;
        cout << "\t2) Selection Of Car" << endl;
        cout << "\t3) Display Data" << endl;
        cout << "\t4) Exit\033[0m" << endl
            << endl;

    label:
        cout << "Enter : ";
        cout << "\033[36m";
        cin >> choice;
        cout << "\033[0m";

        switch (choice)
        {
        case 1:
        {
            UpdateYourData();
        }
        break;
        case 2:
        {
            Search s;
            s.Print();
        }
        break;
        case 3:
        {
            DisplayCustomerData();
        }
        break;
        case 4:
        {
            ReturnToMainMenuOfCustomer();
            return;
        }
        break;
        default:
        {
            // Invalid input handling
        }
        }
    }
}

void Search::Print()
{
    {
        cout << endl
            << "\t\t\t\t\t\033[32mChoose any of the following Option \033[0m" << endl
            << endl
            << endl;
        cout << "\033[34m\t1) VIP Ride " << endl;
        cout << "\t2) Economy Class Ride " << endl;
        cout << "\t3) Regular Ride " << endl;
        cout << "\t4) Newly Added Cars " << endl;
        cout << "\t5) Exit\033[0m" << endl
            << endl;
    label:
        cout << "Enter : ";
        cout << "\033[36m";
        cin >> choicee;
        cout << "\033[0m";
        switch (choicee)
        {
        case 1:
        {
            VIPRide();
        }
        break;
        case 2:
        {
            EconomyClassRide();
        }
        break;
        case 3:
        {
            RegularRide();
        }
        break;

        case 4:
        {
            NewlyAddedCars();
        }
        break;

        case 5:
        {
            ReturnToMainMenuOfCustomer();
        }
        break;
        default:
        {
            cout << endl
                << "\033[31mInvalid Input , Please Enter your choice again\033[0m" << endl
                << endl;
            goto label;
        }
        }
    }
}

void Report::Print()
{
    {
        cout << endl
            << "\t\t\t\t\t\033[32mChoose any of the following Option \033[0m" << endl
            << endl
            << endl;
        cout << "\033[35m\t1) Rented Cars Report " << endl;
        cout << "\t2) Exit\033[0m" << endl
            << endl;
    label:
        cout << "Enter : ";
        cout << "\033[36m";
        cin >> choice;
        cout << "\033[0m";
        switch (choice)
        {
        case 1:
        {
            RentedCarsReport();
        }
        break;
        case 2:
        {
            ReturnToMainMenuOfManager();
        }
        break;
        default:
        {
            cout << endl
                << "\033[31mInvalid Input , Please Enter your choice again\033[0m" << endl
                << endl;
            goto label;
        }
        }
    }
}

int main()
{

    MainMenu M1;
    M1.PrintFirstChoice();

    return 0;
}